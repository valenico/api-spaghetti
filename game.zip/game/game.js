var config = {
    type: Phaser.AUTO,
    width: 700,
    height: 600,
    parent: "game",
    pixelArt: true,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 }
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

var game = new Phaser.Game(config);
var backgroundMusic;
let cursors;
let player;
let guy1;
let guy2;
let fridge;
let tv;

let dialog = false;
let end = false;
let text;
var box;
var index = 0;
var line = '';
var audio;

var content = [
  "What the fuck are you doing junkie?! Go open the fridge!",
  "WTF am I too high or are the NFTs talking?! Ok enough, check the damn fridge!",
  "TO THE MOOOOON!",
  "The everything bubble is about to burst!",
  "I don't give a fuck! I'm the one who dictates market direction.",
  "BREAKING NEWS: There is a new collective in town that is taking over everything, in the streets you can hear",
  "is taking over everything, in the streets you can hear ",
  "their name screamed out loud.... SpaghettiPunk!"
]

function preload () {
  this.load.image('tiles', './assets/SPAGHETTIKITCHEN.png');
  this.load.tilemapTiledJSON("map", "./assets/SpaghettiMap.json");
  this.load.image("transparent", "./assets/transparent.png");

  this.load.image('front-left',"./assets/PUNK/PUNK FRONT LEFT.png");
  this.load.image('front-right',"./assets/PUNK/PUNK FRONT RIGHT.png");
  this.load.image('front-still',"./assets/PUNK/PUNK front.png");
  this.load.image("profilo-destro","./assets/PUNK/PUNK PROFILO DESTRO.png");
  this.load.image('profilo-sinistro',"./assets/PUNK/PUNK PROFILO SINISTRO.png");
  this.load.image("run-destro","./assets/PUNK/PUNK RUN DESTRO.png");
  this.load.image('run-sinistro',"./assets/PUNK/PUNK RUN SINISTRO.png");
  this.load.image('back-still',"./assets/PUNK/PUNK SPALLE FERMO.png");
  this.load.image('back-right',"./assets/PUNK/PUNK SPALLE RUN DESTRO.png");
  this.load.image('back-left',"./assets/PUNK/PUNK SPALLE RUN SINISTRO.png");

  this.load.image('trasparente',"./assets/PUNK/output-onlinepngtools.png");
  //this.load.audio('background_music', ['./assets/soundtrack.mp3', './assets/soundtrack.ogg']);
  //this.load.audio('background_music','./assets/soundtrack.mp3');
}

function create () {
  //var sprite = this.add.image(400, 300, 'tiles');
  const map = this.make.tilemap({ key: "map" });

  const tileset = map.addTilesetImage("SPAGHETTIKITCHEN", "tiles");

  const worldLayer = map.createLayer("World", tileset, 0, 0);
  const aboveLayer = map.createLayer("AbovePlayer", tileset, 0, 0);
  worldLayer.setCollisionByProperty({ collides: true });

  const spawnPoint = map.findObject("Objects", obj => obj.name === "spawn");

  const guy1obj = map.findObject("Objects", obj => obj.name === "guy1");
  const guy2obj = map.findObject("Objects", obj => obj.name === "guy2");
  const fridgeobj = map.findObject("Objects", obj => obj.name === "fridge");
  const bullobj = map.findObject("Objects", obj => obj.name === "bull");
  const bearobj = map.findObject("Objects", obj => obj.name === "bear");
  const whaleobj = map.findObject("Objects", obj => obj.name === "whale");
  const tv = map.findObject("Objects", obj => obj.name === "tv");

  audio = new Audio('./assets/soundtrack.ogg');
  audio.addEventListener('ended', function() {
          audio.currentTime = 0;
          audio.play();
      }, false);
  audio.play();

  aboveLayer.setDepth(10);
  player = this.physics.add.
  sprite(spawnPoint.x, spawnPoint.y, 'front-still').
  setSize(30, 40).
  setOffset(0, 24).setInteractive();

  guy1 = this.physics.add.
  sprite(guy1obj.x, guy1obj.y, 'transparent').
  setSize(70, 50).
  setOffset(0, 24);

  guy2 = this.physics.add.
  sprite(guy2obj.x, guy2obj.y, 'transparent').
  setSize(70, 50).
  setOffset(0, 24);

  fridge = this.physics.add.
  sprite(fridgeobj.x, fridgeobj.y, 'transparent').
  setSize(70, 50).
  setOffset(0, 24);

  bull = this.physics.add.
  sprite(bullobj.x, bullobj.y, 'transparent').
  setSize(70, 50).
  setOffset(0, 24);

  bear = this.physics.add.
  sprite(bearobj.x, bearobj.y, 'transparent').
  setSize(70, 50).
  setOffset(0, 24);

  whale = this.physics.add.
  sprite(whaleobj.x, whaleobj.y, 'transparent').
  setSize(70, 50).
  setOffset(0, 24);

  this.physics.add.collider(player, worldLayer);
  player.setCollideWorldBounds(true);

  const anims = this.anims;

  anims.create({
    key: "punk-right-walk",
    frames: [
          { key: 'profilo-destro' },
          { key: 'run-destro' }
      ],
    frameRate: 10,
    repeat: -1
  });

  anims.create({
    key: "punk-left-walk",
    frames: [
            { key: 'profilo-sinistro' },
            { key: 'run-sinistro' }
        ],
    frameRate: 10,
    repeat: -1
  });

  anims.create({
    key: "punk-front-walk",
    frames: [
            { key: 'front-left' },
            { key: 'front-right' }
        ],
    frameRate: 10,
    repeat: -1
  });
    anims.create({
      key: "punk-back-walk",
      frames: [
              { key: 'back-left' },
              { key: 'back-right' }
          ],
      frameRate: 10,
      repeat: -1
    });


    const camera = this.cameras.main;
    camera.startFollow(player);
    camera.setBounds(0, 0, map.widthInPixels, map.heightInPixels);
    cursors = this.input.keyboard.createCursorKeys();


    this.add.
    text(16, 16, 'Arrow keys to move\nPress "ENTER" to interact', {
      font: "18px monospace",
      fill: "#000000",
      padding: { x: 0, y: 0 },
      backgroundColor: "#ffffff" }).
      setScrollFactor(0).
      setDepth(30);

    box = document.getElementById("box");
    text = document.getElementById("text");

    var keyObj = this.input.keyboard.addKey('ENTER');
    this.input.keyboard.on('keydown-ENTER', () => {
      if(!end && (player.x - fridge.x) < 30 && (player.x - fridge.x) > -30 && (player.y - fridge.y) < 60 && (player.y - fridge.y) > -60){
        end = true;
        dialog = true;
        camera.fadeOut(2000, 0, 0, 0);
        setTimeout(function() {audio.pause()}, 3000);

      }
    })



      keyObj.on('down', function(event) {
        if((player.x - guy1.x) < 75 && (player.x - guy1.x) > -75 && (player.y - guy1.y) < 75 && (player.y - guy1.y) > -75){
          if(box.style.display === 'none'){
            text.innerText = "";
            box.style.display = 'block';
            dialog = true;
            nextLine(0);
          }
          else{
            box.style.display = 'none';
            dialog = false;
          }
         }

         if((player.x - guy2.x) < 75 && (player.x - guy2.x) > -75 && (player.y - guy2.y) < 75 && (player.y - guy2.y) > -75){
           if(box.style.display === 'none'){
             text.innerText = "";
             box.style.display = 'block';
             dialog = true;
             nextLine(1);
           }
           else{
             box.style.display = 'none';
             dialog = false;
           }
          }

           if((player.x - whale.x) < 75 && (player.x - whale.x) > -85 && (player.y - whale.y) < 75 && (player.y - whale.y) > -82){
             if(box.style.display === 'none'){
               text.innerText = "";
               box.style.display = 'block';
               dialog = true;
               nextLine(4);
             }
             else{
               box.style.display = 'none';
               dialog = false;
             }

            }
            if((player.x - bull.x) < 70 && (player.x - bull.x) > -85 && (player.y - bull.y) < 75 && (player.y - bull.y) > -75){
              if(box.style.display === 'none'){
                text.innerText = "";
                box.style.display = 'block';
                dialog = true;
                nextLine(2);
              }
              else{
                box.style.display = 'none';
                dialog = false;
              }
             }

             if((player.x - bear.x) < 75 && (player.x - bear.x) > -75 && (player.y - bear.y) < 75 && (player.y - bear.y) > -75){
               if(box.style.display === 'none'){
                 text.innerText = "";
                 box.style.display = 'block';
                 dialog = true;
                 nextLine(3);
               }
               else{
                 box.style.display = 'none';
                 dialog = false;
               }
              }

              if((player.x - tv.x) < 75 && (player.x - tv.x) > -75 && (player.y - tv.y) < 75 && (player.y - tv.y) > -75){
                if(box.style.display === 'none'){
                  text.innerText = "";
                  box.style.display = 'block';
                  dialog = true;
                  nextLine(5);
                }
                else{
                  box.style.display = 'none';
                  dialog = false;
                }
               }
      });
}



function update(time, delta) {

  if(dialog === false){
    const speed = 175;
    const prevVelocity = player.body.velocity.clone();

    // Stop any previous movement from the last frame
    player.body.setVelocity(0);

    // Horizontal movement
    if (cursors.left.isDown) {
      player.body.setVelocityX(-speed);
    } else if (cursors.right.isDown) {
      player.body.setVelocityX(speed);
    }

    // Vertical movement
    if (cursors.up.isDown) {
      player.body.setVelocityY(-speed);
    } else if (cursors.down.isDown) {
      player.body.setVelocityY(speed);
    }

    // Normalize and scale the velocity so that player can't move faster along a diagonal
    player.body.velocity.normalize().scale(speed);

    // Update the animation last and give left/right animations precedence over up/down animations
    if (cursors.left.isDown) {
      player.anims.play("punk-left-walk", true);
    } else if (cursors.right.isDown) {
      player.anims.play("punk-right-walk", true);
    } else if (cursors.up.isDown) {
      player.anims.play("punk-back-walk", true);
    } else if (cursors.down.isDown) {
      player.anims.play("punk-front-walk", true);
    } else {
      player.anims.stop();

      // If we were moving, pick and idle frame to use
      if (prevVelocity.x < 0) player.setTexture("profilo-sinistro");else
      if (prevVelocity.x > 0) player.setTexture("profilo-destro");else
      if (prevVelocity.y < 0) player.setTexture('back-still');else
      if (prevVelocity.y > 0) player.setTexture('front-still');
    }
  }
  else {
    const prevVelocity = player.body.velocity.clone();
    player.anims.stop();
    player.body.setVelocity(0);
    if (prevVelocity.x < 0) player.setTexture("profilo-sinistro");else
    if (prevVelocity.x > 0) player.setTexture("profilo-destro");else
    if (prevVelocity.y < 0) player.setTexture('back-still');else
    if (prevVelocity.y > 0) player.setTexture('front-still');
  }

}

function updateLine() {
  if (line.length < content[index].length)
  {
      line = content[index].substr(0, line.length + 1);
      if(index ==7) text.innerText = content[6] + line;
      else text.innerText = line;
  }
  else if(index==5) nextLine(7);
}


function nextLine(idx) {
  index = idx
  line = '';

  var j=0;
  for(;j<content[index].length+1;j++){
    setTimeout(updateLine, j*40);
  }
}
